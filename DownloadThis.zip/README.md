README for battleship-3k

This is a project for TDAT1006 System Development with Database Project

Installation guide:  
-Download Battleship-3k.zip  
-Extract the run directory to somewhere on your computer  
-Open the run directory  
-Doubleclick the Battleship 3k.bat file. The program now generates a file called dbConfig.properties  
-Close the program  
-Go to run/src/main/java  
-Open dbConfig.properties  
-Add configurations for your database. For using our database send a message to magbre@stud.ntnu.no  
-Go back to run directory  
-Dubleclick the Battleship 3k.bat file again.   
-Enjoy your game :)  